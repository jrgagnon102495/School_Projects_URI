#include "dealer.h"
#include "deck.h"
#include"player.h"
#include <iostream>
#define WIN_THRESHOLD 21
#include <vector>

Dealer::Dealer(std::vector<Card> deck, std::vector<Card>dealer_hand){
 
    this->deck = deck;
    this->dealer_hand = dealer_hand;
    this->card_amount = 2;
}
Dealer::Dealer(){
 Deck dealer_deck;
  dealer_deck.shuffleDeck(dealer_deck.getDeck());
 std::vector<Card>copyDeck;
for(int i = 0; i< 52; i++){
    copyDeck.push_back(dealer_deck.getDeck()[i]);
}
for(int j = 0; j < 52; j++){
 this->deck.push_back(copyDeck[j]);
}

}
int Dealer::getDealerCardAmount(){
 for(int i = dealer_hand.size()-1; i>=0; i--){
  this->totalValue+=dealer_hand[i].getValue();
 }
 return this->totalValue;
}
void Dealer::hitDealerHand(Card card){
  dealer_hand.push_back(card);
     this->card_amount++;
}
std::vector<Card> Dealer:: getDealerHand(){
 return this->dealer_hand;
}
 void  Dealer::gameStatus(Player *player){
  
     int value;
     int dealer_value;

     dealer_value = dealer_hand.back().getValue() + dealer_hand.front().getValue();
     for(int i = 0; i < player->getCardAmount(); i++){
        value += dealer_hand[i].getValue();
     }
     if(dealer_value > WIN_THRESHOLD){
       if(player->betAmount(this->chip_amount) == 1){
              player->getChips1().push(1);
              player->getChips1().push(1);

           }
           else if(player->betAmount(this->chip_amount) == 5){
            player->getChips5().push(5);
            player->getChips5().push(5);
           }
           else if(player->betAmount(this->chip_amount) == 10){
            player->getChips10().push(10);
            player->getChips10().push(10);
           }
           else if(player->betAmount(this->chip_amount) == 25){
            player->getChips25().push(25);
            player->getChips25().push(25);

           }
           else if(player->betAmount(this->chip_amount) == 50){
            player->getChips50().push(50);
            player->getChips50().push(50);
           }
     }
     if(value <= WIN_THRESHOLD){
         if(value > dealer_value){
          if(player->betAmount(this->chip_amount) == 1){
              player->getChips1().push(1);
              player->getChips1().push(1);

           }
           else if(player->betAmount(this->chip_amount) == 5){
            player->getChips5().push(5);
            player->getChips5().push(5);
           }
           else if(player->betAmount(this->chip_amount) == 10){
            player->getChips10().push(10);
            player->getChips10().push(10);
           }
           else if(player->betAmount(this->chip_amount) == 25){
            player->getChips25().push(25);
            player->getChips25().push(25);

           }
           else if(player->betAmount(this->chip_amount) == 50){
            player->getChips50().push(50);
            player->getChips50().push(50);
           }
     }
           else{
            return;
           }


          }
         else{
          return;
         }
    }

std::vector<Card> Dealer::dealer_deal(std::vector<Card>copyDeck){
 
 
    if(copyDeck.empty()){
        return copyDeck;
    }
    
     for(int i =0; i < 2 ; i++){
       
       this->dealer_hand.push_back(copyDeck.back());
       this->card_amount++;
       copyDeck.pop_back();
    //   std::cout<<this->hand[i].toString()<<std::endl;
   }
   
   return copyDeck;

}
 std::string Dealer::to_stringAG(){
   std::string str = "";
   str+="Dealer Hand: ";
 std::vector<Card>copyHand;
    for(int j = 0; j < dealer_hand.size(); j++){
        copyHand.push_back(this->dealer_hand[j]);
        // std::cout<<this->hand[j].toString()<<std::endl;
        
    }
     std::stringstream ss;
    // std::cout<<this->card_amount<<std::endl;
     str+="\n";
    for(int i = copyHand.size()-1; i>=0;  i-- ){
      
      
     
        str+=copyHand[i].toString();
    
        str+=" ";
    
        
    }
    return str;

 }
  std::string Dealer::to_stringBG(){
   std::string str = "";
   str+="Dealer Hand: ";
 std::vector<Card>copyHand;
    for(int j = 0; j < dealer_hand.size(); j++){
        copyHand.push_back(this->dealer_hand[j]);
        // std::cout<<this->hand[j].toString()<<std::endl;
        
    }
     std::stringstream ss;
    // std::cout<<this->card_amount<<std::endl;
     str+="\n";
  str+=copyHand.front().toString();
    return str;

 }