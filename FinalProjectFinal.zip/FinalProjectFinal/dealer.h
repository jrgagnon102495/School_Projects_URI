#ifndef DEALER_H
#define DEALER_H

#include"player.h"
#include "deck.h"
#include <string>
#include <vector>
#include "card.h"
#include <stack>
class Dealer{
    private:
    std::vector<Card> deck;
    std::vector<Card> dealer_hand;
    int totalValue = 0;
    int card_amount;
    int chip_amount;
    public:
    Dealer(std::vector<Card>deck,  std::vector<Card>dealer_hand);
    Dealer();
    void hitDealerHand(Card card);
    int getDealerCardAmount();
    std::vector<Card> getDealerHand();
    void gameStatus(Player *player1);
    std::vector<Card> dealer_deal(std::vector<Card>copyDeck);
    std::string to_stringBG();
    std::string to_stringAG();
    
    friend class Table;
    friend class Player;
};

#endif