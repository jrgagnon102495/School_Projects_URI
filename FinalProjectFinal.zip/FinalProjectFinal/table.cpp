#include "dealer.h"
#include <queue>
#include "player.h"
#include "card.h"
#include "table.h"
#define DEFAULT_HAND 2
Table::Table(Dealer dealer, std::queue<Player> players, int maxPlayers, Player *spaces[]){
    
   this->dealer = dealer;
   for(int j = 0; j < MAX_PLAYERS; j++){
       this->spaces[j] = spaces[j];
   }
   for(int i = 0; i < maxPlayers; i++){
       Player player;
       players.push(player);
       
   }
   
   
}
//queue to enter the 4 allotted spaces on the table
int Table::getNumberOfPlayers(){
    this->numberOfPlayers = players.size();
    if(this->numberOfPlayers > this->maxPlayers){
        int sizeOver = (this->numberOfPlayers - this->maxPlayers);
        
        for(int i = 0; i < sizeOver; i++){
            this->players.pop();
            this->numberOfPlayers = players.size();
        }
        return this->numberOfPlayers;
    }
    return this->numberOfPlayers;
}
void Table::space(std::vector<Card> remDeck){

    std::vector<Card> hand;
    for(int r = 0; r < DEFAULT_HAND; r++){
        hand.push_back(remDeck.back());
        remDeck.pop_back();
        
    }

    
    for(int i = 0; i < MAX_PLAYERS; i++){
        if(this->spaces[0] == NULL ){
            
            spaces[0] = &players.front();
            spaces[0]->dealCards(hand);
        
           players.pop();
           Player* player1 = new Player();
           players.push(*player1);
           break;
        }
        else if(spaces[1] == nullptr){
            spaces[1] = &players.front();
            spaces[1]->dealCards(hand);
            
           
            players.pop();
             Player* player2 = new Player();
             
            players.push(*player2);
            
            break;
        }
        else if(spaces[2] == nullptr){
            spaces[2] = &players.front();
            spaces[2]->dealCards(hand);
            
             players.pop();
            Player* player3 = new Player();
            players.push(*player3);
            break;
        }
        else if(spaces[3] == nullptr){
            spaces[3] = &players.front();
            spaces[3]->dealCards(hand);
            
            
            players.pop();
            Player* player4 = new Player();
            players.push(*player4);
            break;
        }
        else{
            
        }
    }
}
Player* Table::getSpace1(){
    return this->spaces[0];
}
Player* Table::getSpace2(){
    return this->spaces[1];
}
Player* Table::getSpace3(){
    return this->spaces[2];
}
Player* Table::getSpace4(){
    return this->spaces[3];
}

std::string Table:: to_stringBG(){
     std::string str = "";
    str+="[";
    str+="Before Game";
    str+="]";
    str+="\n";
    str+=this->dealer.to_stringBG();
    str+="\n";
    
    for(int i  = 0; i < MAX_PLAYERS; i++){
        str+=spaces[i]->to_string();
        str+="\n";
    }
    
    for(std::queue<Player>displayPlayers = players; !displayPlayers.empty(); displayPlayers.pop()){
        
        str+=" ";
        str+=displayPlayers.front().to_string();
        str+=" ";
        displayPlayers.pop();
        str+="\n";
    }
    return str;
}
std::string Table::to_stringAG(){
    std::string str = "";
    str+="[";
    str+="After Game";
    str+="]";
    str+="\n";
    str+=this->dealer.to_stringAG();
    str+="\n";
    
    for(int i  = 0; i < MAX_PLAYERS; i++){
        str+=spaces[i]->to_string();
        str+="\n";
    }
    
    for(std::queue<Player>displayPlayers = players; !displayPlayers.empty(); displayPlayers.pop()){
        
        str+=" ";
        str+=displayPlayers.front().to_string();
        str+=" ";
        displayPlayers.pop();
        str+="\n";
    }
    return str;
}
