#include <iostream>
#include "card.h"
#include <stack>
#include <queue>
#include "deck.h"
#define MAX 52
#define DIAMOND 'D'
#define HEART 'H'
#define SPADE 'S'
#define CLUBS 'C'
#include <array>
#include "player.h"
#include "dealer.h"
#include "table.h"

int main(){


    std:: stack<int> chips1;
     std:: stack<int> chips5;
      std:: stack<int> chips10;
       std:: stack<int> chips25;
        std:: stack<int> chips50;
      //1 stack
     chips1.push(1);
      chips1.push(1);
       chips1.push(1);
        chips1.push(1);
         chips1.push(1);

     //5 stack
     chips5.push(5);
       chips5.push(5);
         chips5.push(5);
             chips5.push(5);

     //10 stack
     chips10.push(10);
     chips10.push(10);
     chips10.push(10);

     //15 stack
     chips25.push(25);
     chips25.push(25);


     //25
     chips50.push(50);

   // for (std::stack<int> display = chips1; !display.empty(); display.pop())
   //      std::cout <<" ["<< display.top() <<"] ";

   //      std::cout<<""<<std::endl;
   //  std::cout << "(" << chips.size() << " chips) \n";

//Player1


//Player2


//testing card class
Card* card = new Card(11, DIAMOND, 'K');
// std::cout<<card->getValue()<<std::endl;
// std::cout<<card->getSuit()<<std::endl;
// std::cout<<card->toString()<<std::endl;





//testing shuffling deck
 Deck dealer_deck;
 // std::cout<<dealer_deck.to_string()<<std::endl;
 dealer_deck.shuffleDeck(dealer_deck.getDeck());
 // std::cout<<dealer_deck.to_string()<<std::endl;


//Copying over to a hand
std::vector<Card> hand;

std::vector<Card>copyDeck;
for(int i = 0; i< 52; i++){
    copyDeck.push_back(dealer_deck.getDeck()[i]);
}
hand.push_back(copyDeck.back());
//std::cout<<hand.back().toString()<<std::endl;
  copyDeck.pop_back();
  hand.push_back(copyDeck.back());
//  std::cout<<hand.back().toString()<<std::endl;
  copyDeck.pop_back();

//Create a player 
 Player* player1 = new Player(chips1, chips5, chips10, chips25, chips50, hand );
 // std::cout<<player1->to_string()<<std::endl;
 player1->split(hand);
 // std::cout<<player1->splitLeft().front().toString()<<std::endl;
 // std::cout<<player1->splitRight().front().toString()<<std::endl;
 player1->betAmount(1);
 // std::cout<<player1->to_string()<<std::endl;
 player1->hitCard(copyDeck.back());
 copyDeck.pop_back();
 
 // std::cout << player1->to_string()<<std::endl;
 
 player1->doubleDown(copyDeck.back(), player1->betAmount(20));
 // std::cout<<player1->getBetAmount()<<std::endl;
 // std::cout<<player1->to_string()<<std::endl;
 
Card hand1=copyDeck.back();
 copyDeck.pop_back();
 Card hand2 = copyDeck.back();
 
 //Create a dealer
 std::vector<Card>dealer_hand;
 for(int j = 0; j < 2; j++){
  dealer_hand.push_back(copyDeck.back());
  copyDeck.pop_back();
 }
 
 
 Dealer* dealer1 = new Dealer(copyDeck, dealer_hand);
 // std::cout<<dealer1->to_stringBG()<<std::endl;
 dealer1->gameStatus(player1);
 // std::cout<<player1->to_string()<<std::endl;
 // std::cout<<dealer1->to_stringAG()<<std::endl;
 // std::cout<<""<<std::endl;



//Create a Table
int maxPlayers = 4;
std::queue<Player>players;
Player* spaces[MAX_PLAYERS];
for(int k = 0; k < MAX_PLAYERS; k++){
 Player *player = new Player();
 players.push(*player);
 
}
// for(std::queue<Player>displayPlayers = players; !displayPlayers.empty(); displayPlayers.pop()){
//  std::cout<<displayPlayers.front().to_string()<<std::endl;

 
// }
for(int m = 0; m < 4; m++){
  
  spaces[m] = &players.front();
 
 players.pop();
 Player* player = new Player();
 players.push(*player);
 copyDeck = spaces[m]->dealCards(copyDeck);
 //std::cout<<spaces[m]->to_string()<<std::endl;
 
 
}
Table* game_table = new Table(*dealer1, players,MAX_PLAYERS, spaces);


//testing changing Ace value
Player* player2 = new Player();
Card* ace1 = new Card(11,  DIAMOND, 'A');
Card* ace2 = new Card(11, SPADE, 'A');
std::vector<Card> handAce;
player2->betAmount(10);
handAce.push_back(*ace1);
handAce.push_back(*ace2);
player2->dealCards(handAce);
//player2->changeAceVal(player2->getCards());

      
      
//std::cout<<player2->to_string()<<std::endl;

 // Player* playercheck = new Player();
 // char cont = 'Y';
 // char hit;
 // char doubdown;
 // char split;
 // std::cout<<cont<<std::endl;
 // while(cont == 'Y' || cont == 'y'){
     
 //     std::cout<<"Hit (true or false):  ";
 //     std::cin >> hit;
 //     while(!std::cin >> hit){
 //      std::cout<<"Please hit: "<<std::endl;
 //      std::cin.clear();
 //      std::cin.ignore(100, '\n');
      
 //     }
 //     if(hit == 'Y' || hit == 'y'){
 //      playercheck->hitCard(copyDeck.back());
 //      copyDeck.pop_back();
 //      hit = 'Y';
 //     }
 //    std::cout<<"Double Down (Y or N):  "<<" ";
 //     std::cin >> doubdown;
 //     if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
 //      std::cout<<"Split(Y or N):  "<<std::endl;
 //      std::cin >> split;
 //     }
 //    std:: cout<<"Continue: (true or false): "<<std::endl;
 //    std::cin>>cont;
 //    }
    

//std::cout<<game_table->to_stringBG()<<std::endl;
//std::cout<<game_table->to_stringAG()<<std::endl;
//Game

// if(player1->betAmount(amount) == -1){
 //queue<Player> players.pop();
   
//}

//First Loop
//cycle through the players
//Do this by cycling through spaces and using the table classes methods to access each space
//while accessing each space make sure to keep on looping with questions (split[if their cards are the same value], hit, double down)
//if the person says no to hitting again then the the loop cycles to the next player
 Player* playercheck = new Player();
 char gamecont = 'Y';
while(gamecont == 'Y' || gamecont == 'y' ){
 std::cout<<dealer1->to_stringBG()<<std::endl;
for(int p = 0; p < MAX_PLAYERS; p++){
 playercheck = spaces[p];
 char hit;
 char insure;
 char cont = 'Y';
 int bet;
 int choice;
 
   if(playercheck == spaces[0]){
    std::cout<<"What do you want to bet?:  1, 5, 10 , 25, 50  "<<std::endl;
    std::cin>>bet;
    spaces[0]->betAmount(bet);
    
   bool splitcheck = false;
    while(cont == 'Y' || cont == 'y'){
     if(dealer1->getDealerHand().front().getFace() == 'A'){
      std::cout<<"Do you want to insure you don't lose? (Y or N?):"<<std::endl;
      if(insure == 'Y' || insure == 'y'){
       spaces[0]->insuranceBet(playercheck->getBetAmount());
      }
      
      
     }
     spaces[0]->changeAceVal(playercheck->getCards());
    std::cout<<playercheck->to_string()<<std::endl;
    if(splitcheck == true){
    char splitright = 'Y';
    char splitleft = 'Y';
     while (splitright == 'Y'){
        std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
       std::cin>>choice;
       switch(choice)
      {
       case 1:
       spaces[0]->hitRight(copyDeck.back());
       copyDeck.pop_back();
       case 2:
        spaces[0]->doubleDown(copyDeck.back(), playercheck->getBetAmount());
       default:
       spaces[0]->hitRight(copyDeck.back());
       copyDeck.pop_back();
       
       }
     }
     while(splitleft == 'Y'){
      
     }
    }
    //  std::cout<<"Hit (Y or N):  "<<std::endl;
    //  std::cin >> hit;
    // // std::cout<<"HI"<<std::endl;
    //  while(!std::cin >> hit){
    //   //std::cout<<"Hello"<<std::endl;
    //   std::cout<<"Hit(Y or N):  "<<std::endl;
    //   std::cin.clear();
    //   std::cin.ignore(100, '\n');
    //  }
    //  if(hit == 'Y' || hit == 'y'){
    //   playercheck->hitCard(copyDeck.back());
    //   copyDeck.pop_back();
    //   hit = 'N';
    //  }
    // std::cout<<"Double Down (Y or N):  "<<" ";
    //  std::cin >> doubdown;
    //  if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
    //   std::cout<<"Split(Y or N):  "<<std::endl;
    //   std::cin >> split;
    //  }
    if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
    std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down], 3. [Split]"<<std::endl;
       std::cin>>choice;
       switch(choice)
       {
       case 1:
       spaces[0]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
      spaces[0]->doubleDown(copyDeck.back(),playercheck->getBetAmount());
       copyDeck.pop_back();
       break;
       case 3:
       spaces[0]->split(playercheck->getCards());
       copyDeck.pop_back();
       break;
       default:
      spaces[0]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
      }
       
    } 
      
       else{
       std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
       std::cin>>choice;
       switch(choice)
      {
       case 1:
       spaces[0]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
        spaces[0]->doubleDown(copyDeck.back(), playercheck->getBetAmount());
        copyDeck.pop_back();
        break;
       default:
       spaces[0]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       
       }
       }
     std::cout<<playercheck->to_string()<<std::endl;
    std::cout<<"Continue?: (Y or N) "<<std::endl;
    std::cin>>cont;
    }
   }
   else if(playercheck == spaces[1]){
    std::cout<<"What do you want to bet?:  1, 5, 10 , 25, 50  "<<std::endl;
    std::cin>>bet;
    spaces[1]->betAmount(bet);
    
    //std::cout<<playercheck->to_string()<<std::endl;
    while(cont == 'Y' || cont == 'y'){
     
     if(dealer1->getDealerHand().front().getFace() == 'A'){
      std::cout<<"Do you want to insure you don't lose? (Y or N?):"<<std::endl;
      if(insure == 'Y' || insure == 'y'){
       spaces[1]->insuranceBet(playercheck->getBetAmount());
      }
      
      
     }
     spaces[1]->changeAceVal(playercheck->getCards());
     /**if(spaces[1]->getCards().front().getValue() == spaces[1]->getCards().back().getValue()){
      *std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down], 3. [Split]"<<std::endl;
      * std::cin>>choice;
      * switch(choice)
      * {
      * case 1:
      * playercheck->hitCard(copyDeck.back());
      * copyDeck.pop_back();
      * 
      * case 2:
      * playercheck->doubleDown(copyDeck.back());
      * copyDeck.pop_back();
      * case 3:
      * playercheck->split(copytDeck.back());
      * copyDeck.pop_back();
      * default:
      * playercheck->hitCard(copyDeck.back());
      * copyDeck.pop_back();
      * 
      *}
      * 
      * }
      *
      * else{
      * std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
      * std::cin>>choice;
      * switch{
      * case 1:
      * playercheck->
      * case 2:
      * default:
      * 
      * 
      * }
      * 
      * 
      * 
      * */
      
      std::cout<<playercheck->to_string()<<std::endl;
    //  std::cout<<"Hit (Y or N):  "<<std::endl;
    //  std::cin >> hit;
    //  std::cout<<"HI"<<std::endl;
    //  while(!std::cin >> hit){
    
    //   std::cout<<"Hit(Y or N):  "<<std::endl;
    //   std::cin.clear();
    //   std::cin.ignore(100, '\n');
    //  }
    //  if(hit == 'Y' || hit == 'y'){
    //   playercheck->hitCard(copyDeck.back());
    //   copyDeck.pop_back();
    //   hit = 'N';
    //  }
    // std::cout<<"Double Down (Y or N):  "<<" ";
    //  std::cin >> doubdown;
    //  if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
    //   std::cout<<"Split(Y or N):  "<<std::endl;
    //   std::cin >> split;
    //  }
     if(spaces[1]->getCards().front().getValue() == spaces[1]->getCards().back().getValue()){
    std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down], 3. [Split]"<<std::endl;
       std::cin>>choice;
       switch(choice)
       {
       case 1:
       spaces[1]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
         spaces[1]->doubleDown(copyDeck.back(),playercheck->getBetAmount());
       copyDeck.pop_back();
       case 3:
        spaces[1]->split(playercheck->getCards());
       copyDeck.pop_back();
       break;
       default:
        spaces[1]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       
      }
       
    } 
      
       else{
       std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
       std::cin>>choice;
       switch(choice)
      {
       case 1:
       spaces[1]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
        spaces[1]->doubleDown(copyDeck.back(), playercheck->getBetAmount());
        copyDeck.pop_back();
        break;
       default:
       spaces[1]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       
       }
       }
     std::cout<<playercheck->to_string()<<std::endl;
    std::cout<<"Continue?: (Y or N) "<<std::endl;
    std::cin>>cont;
    }
   }
   else if(playercheck == spaces[2]){
   std::cout<<"What do you want to bet?:  1, 5, 10 , 25, 50  "<<std::endl;
    std::cin>>bet;
    spaces[2]->betAmount(bet);
    
    //std::cout<<playercheck->to_string()<<std::endl;
    while(cont == 'Y' || cont == 'y'){
      if(dealer1->getDealerHand().front().getFace() == 'A'){
      std::cout<<"Do you want to insure you don't lose? (Y or N?):"<<std::endl;
      if(insure == 'Y' || insure == 'y'){
       spaces[2]->insuranceBet(playercheck->getBetAmount());
      }
      
      
     }
     spaces[2]->changeAceVal(playercheck->getCards());
     std::cout<<playercheck->to_string()<<std::endl;
    //  std::cout<<"Hit (Y or N):  "<<std::endl;
    //  std::cin >> hit;
   
    //  while(!std::cin >> hit){
    
    //   std::cout<<"Hit(Y or N):  "<<std::endl;
    //   std::cin.clear();
    //   std::cin.ignore(100, '\n');
    //  }
    //  if(hit == 'Y' || hit == 'y'){
    //   playercheck->hitCard(copyDeck.back());
    //   copyDeck.pop_back();
    //   hit = 'N';
    //  }
    // std::cout<<"Double Down (Y or N):  "<<" ";
    //  std::cin >> doubdown;
    //  if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
    //   std::cout<<"Split(Y or N):  "<<std::endl;
    //   std::cin >> split;
    //  }
     if(spaces[2]->getCards().front().getValue() == spaces[2]->getCards().back().getValue()){
    std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down], 3. [Split]"<<std::endl;
       std::cin>>choice;
       switch(choice)
       {
       case 1:
       spaces[2]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       
       case 2:
      spaces[2]->doubleDown(copyDeck.back(),playercheck->getBetAmount());
       copyDeck.pop_back();
       break;
       case 3:
       spaces[2]->split(playercheck->getCards());
       copyDeck.pop_back();
       break;
       default:
      spaces[2]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
      }
       
    } 
      
       else{
       std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
       std::cin>>choice;
       switch(choice)
      {
       case 1:
       spaces[2]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
        spaces[2]->doubleDown(copyDeck.back(), playercheck->getBetAmount());
        copyDeck.pop_back();
        break;
       default:
       spaces[2]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       
       }
       }
     std::cout<<playercheck->to_string()<<std::endl;
    std::cout<<"Continue?: (Y or N) "<<std::endl;
    std::cin>>cont;
    }
   }
   else if(playercheck == spaces[3]){
   std::cout<<"What do you want to bet?:  1, 5, 10 , 25, 50  "<<std::endl;
    std::cin>>bet;
    spaces[3]->betAmount(bet);
    
    std::cout<<playercheck->to_string()<<std::endl;
    while(cont == 'Y' || cont == 'y'){
     std::cout<<spaces[3]->to_string()<<std::endl;
    //  std::cout<<"Hit (Y or N):  "<<std::endl;
    //  std::cin >> hit;
    //  std::cout<<"HI"<<std::endl;
    //  while(!std::cin >> hit){
    //   std::cout<<"Hello"<<std::endl;
    //   std::cout<<"Hit(Y or N):  "<<std::endl;
    //   std::cin.clear();
    //   std::cin.ignore(100, '\n');
    //  }
    //  if(hit == 'Y' || hit == 'y'){
    //   playercheck->hitCard(copyDeck.back());
    //   copyDeck.pop_back();
    //   hit = 'N';
    //  }
    // std::cout<<"Double Down (true or false):  "<<" ";
    //  std::cin >> doubdown;
    //  if(spaces[0]->getCards().front().getValue() == spaces[0]->getCards().back().getValue()){
    //   std::cout<<"Split(Y or N):  "<<std::endl;
    //   std::cin >> split;
    //  }
    //  std::cout<<playercheck->to_string()<<std::endl;
     if(spaces[3]->getCards().front().getValue() == spaces[3]->getCards().back().getValue()){
    std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down], 3. [Split]"<<std::endl;
       std::cin>>choice;
       switch(choice)
       {
       case 1:
       spaces[3]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
      spaces[3]->doubleDown(copyDeck.back(),playercheck->getBetAmount());
       copyDeck.pop_back();
       break;
       case 3:
       spaces[3]->split(playercheck->getCards());
       copyDeck.pop_back();
       break;
       default:
      spaces[3]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
      }
       
    } 
      
       else{
       std::cout<<"What is your choice?: 1. [Hit], 2. [Double Down]"<<std::endl;
       std::cin>>choice;
       switch(choice)
      {
       case 1:
       spaces[3]->hitCard(copyDeck.back());
       copyDeck.pop_back();
       break;
       case 2:
        spaces[3]->doubleDown(copyDeck.back(), playercheck->getBetAmount());
        copyDeck.pop_back();
        break;
       default:
       spaces[3]->hitCard(copyDeck.back());
       
       copyDeck.pop_back();
       break;
       }
       }
       std::cout<<playercheck->to_string()<<std::endl;
    std::cout<<"Continue?: (Y or N) "<<std::endl;
    std::cin>>cont;
    }
   }
}
while(dealer1->getDealerCardAmount() < 17){
 dealer1->hitDealerHand(copyDeck.back());
 copyDeck.pop_back();
 std::cout<<dealer1->to_stringAG()<<std::endl;

}


//Next Loop
//as soon as space 4 player finishes their turn(break), the dealer card is revealed and comparisons are made
//chips are awarded and cards are shuffled back into the deck
//if any player has all of their stacks of chips empty, they are booted from the table 
//and replaced by a new player as the queue is then loaded with another player object 
for(int l = 0; l < MAX_PLAYERS; l++){
  playercheck = spaces[l];
  if(playercheck == spaces[0]){
   dealer1->gameStatus(playercheck);
   if(playercheck->getBetAmount() == -1){
    spaces[0] = &players.front();
     players.pop();
    Player* playerC = new Player();
    players.push(*playerC);
   }
   
  }
  else if(playercheck == spaces[1]){
    dealer1->gameStatus(playercheck);
   if(playercheck->getBetAmount() == -1){
    spaces[1] = &players.front();
     players.pop();
    Player* playerC = new Player();
    players.push(*playerC);
   }
  }
  else if(playercheck == spaces[2]){
    dealer1->gameStatus(playercheck);
   if(playercheck->getBetAmount() == -1){
    spaces[2] = &players.front();
     players.pop();
    Player* playerC = new Player();
    players.push(*playerC);
   }
  }
  else if(playercheck == spaces[3]){
    dealer1->gameStatus(playercheck);
   if(playercheck->getBetAmount() == -1){
    spaces[3] = &players.front();
     players.pop();
    Player* playerC = new Player();
    players.push(*playerC);
   }
  }
}


std::cout<<"Do you want to continue the Game?: "<<std::endl;
std::cin>>gamecont;
Deck dealer_deck1;
dealer_deck1.shuffleDeck(dealer_deck.getDeck());

copyDeck.clear();
dealer1->dealer_deal(copyDeck);
for(int i = 0; i< 52; i++){
    copyDeck.push_back(dealer_deck.getDeck()[i]);
}
for(int o = 0; o < MAX_PLAYERS; o++){

 playercheck=spaces[o];
 if(playercheck == spaces[0]){
 spaces[0]->giveBack();
 spaces[0]->dealCards(copyDeck);
 }
 else if( playercheck == spaces[1]){
 spaces[1]->giveBack();
 spaces[1]->dealCards(copyDeck);
 }
 else if( playercheck == spaces[2]){
  spaces[2]->giveBack();
 spaces[2]->dealCards(copyDeck);
 }
 else if( playercheck == spaces[3]){
  spaces[3]->giveBack();
 spaces[3]->dealCards(copyDeck);
 }
}
}
std::cout<<game_table->to_stringAG()<<std::endl;
    return 0;
}