#ifndef CARD_H
#define CARD_H
#include <iostream>

#include <string>


class Card{
    private:
    

        int value;
        char face;
        char suit;
        
        
    public:
    static const char SPADE = 'S';
    static const char CLUBS = 'C';
    static const char HEART = 'H';
    static const char DIAMOND = 'D';
        Card(int value, char suit, char face);
        char getFace();
        char  getSuit();
         int getValue();
        void setValue(int value);
        std::string toString();
};

#endif