#ifndef DECK_H
#define DECK_H

#include "card.h"
#include <string>
#include <array>
#include <vector>
class Deck{
    private:
     static const int MAX = 52;
    static const int NUM_SUITS = 4;
    static const int NUM_VALUES = 13;
    int numCards;
   
 std::vector<Card>deck;
    public:
    
    Deck();
    Card getTopCard();
    std::vector<Card> getDeck();
    void shuffleDeck(std::vector<Card> deck);
    Card takeTopCard();
    void swap(Card *first_position, Card *second_postion);

    std::string to_string();



};

#endif