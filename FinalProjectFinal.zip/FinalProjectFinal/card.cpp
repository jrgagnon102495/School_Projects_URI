#include <iostream>
#include "card.h"
#include <sstream>

Card::Card(int value, char suit, char face){
    if (value < 1 || value > 13)
    { 
            std::cerr << "Invalid Card value";
    }
    else
    {
       this-> value = value;
    }

    if ((suit != SPADE) && (suit != HEART) && (suit != DIAMOND) && (suit != CLUBS))
    {
        std::cerr << "Invalid Suit name";
    }
    else
    {
        this->suit = suit;
    }
    
    this->face = face;
}

 char Card::getSuit(){
  return this->suit;  
}
int Card::getValue(){
    return this->value;
}
char Card::getFace(){
    return this->face;
}
void Card::setValue(int value){
    this->value = value;
}

std::string Card::toString(){
   std:: string str = "";
   std::stringstream ss;
   ss << this->getValue();
   str+="[ ";
   str+=ss.str();
   str+=", ";
   str+=this->getSuit();
    str+=", ";
    str+=this->getFace();
   str += " ]";
    return str;
}