I am not implementing the split function considering how many different to_string methods i'd have to implement, but will look into doing that as a side
project with other things I plan to add to this 

**SPLIT SHOULD NOT BE USED**

Clearing the hand then starting over is what I did, this particular project challenged me to think outside the box
This entire program is to simulate a game of blackjack using the queues and stacks
I used the templates in the c plus plus library  to add the two data structures to the program
I used stacks for the chips
and 
Queues for the players
[7, H, 7]
[Value, Suit, Face Value]


**Algorithm
//First Loop
//cycle through the players
//Do this by cycling through spaces and using the table classes methods to access each space
//while accessing each space make sure to keep on looping with questions (split[if their cards are the same value], hit, double down)
//if the person says no to hitting again then the the loop cycles to the next player
 
 //Next Loop
//as soon as space 4 player finishes their turn(break), the dealer card is revealed and comparisons are made
//chips are awarded and cards are shuffled back into the deck
//if any player has all of their stacks of chips empty, they are booted from the table 
//and replaced by a new player as the queue is then loaded with another player object 

//Last Loop
//start over by clearing everything
// then deal everyone with a new hand
