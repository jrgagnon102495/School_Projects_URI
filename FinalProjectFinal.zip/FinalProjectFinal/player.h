#ifndef PLAYER_H
#define PLAYER_H


#include <stack>
#include<vector>
#include "card.h"
#include <string>
#include <sstream>
#define HAND_SIZE 2
class Player{
    private:
        std::stack<int>chips1;
        std::stack<int>chips5;
        std::stack<int>chips10;
        std::stack<int>chips25;
        std::stack<int>chips50;
        std::vector<Card> hand; 
        std::vector<Card> splitL;
        std::vector<Card> splitR;
        int card_amount;
        int card_left;
        int card_right;
        int bet_amount = 0;
        bool splitcheck;
    public:
    //used
        Player(std::stack<int>chips1, std::stack<int>chips5, std::stack<int>chips10, std::stack<int>chips25, std::stack<int>chips50, std::vector<Card> hand);
        Player();
        std::vector<Card> dealCards(std::vector<Card>copyDeck);
        
        
        //Not used
        std::vector<Card> splitRight();
        void hitRight(Card Card);
        void hitLeft(Card card);
        std::vector<Card> splitLeft();
        int doubleLeft(Card card, int chip_amount);
        int doubleRight(Card card, int chip_amount);
        int doubleDown(Card card, int chip_amount);
        void split (std::vector<Card> hand);
        
        //Actually used
        std::vector<Card> getCards();
        std::stack<int> getChips1();
        std::stack<int> getChips5();
        std::stack<int> getChips10();
        std::stack<int> getChips25();
        std::stack<int> getChips50();
        void hitCard( Card card);
        int getBetAmount();
        std::vector<Card> changeAceVal(std::vector<Card> hand);
        int getCardAmount();
        int betAmount(int chip_amount);
        int insuranceBet(int chip_amount);
        //not used
        bool isSplit();
        void giveBack();
        
        std::string to_string();
        std::string to_stringSplit();
        
        friend class Table;
        friend class Deck;
};

#endif