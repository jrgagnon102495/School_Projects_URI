#include "deck.h"
#include <iostream>
#include <string>
#include <ctime>
#include "card.h"
#include <array>
#include <algorithm>
#include <random>
#include <chrono>
#include<bits/stdc++.h>
#include <stdlib.h>
#include <time.h>
#include <vector>


Deck::Deck(){
   

    char suit[] = {Card::DIAMOND, Card::SPADE, Card::HEART, Card::CLUBS};
    int value[] = {2,3,4,5,6,7,8,9,10,10,10,10,11};
    char face[] = {'2','3','4','5','6','7','8','9','T','J','Q','K','A'};
    for (int j=0; j<13; j++) {
        for (int i=0; i<4; i++) {
            this->deck.push_back(Card(value[j], suit[i], face[j]));
        }
    }
}
std::vector<Card> Deck::getDeck(){
    return this->deck;
}
void Deck::shuffleDeck(std::vector<Card>deck){

if(deck.empty()){
    return;
}
        std::random_device rd;
    std::default_random_engine rng(rd());
    shuffle(this->deck.begin(), this->deck.end(), rng);

}
Card Deck::takeTopCard(){
     this->deck.pop_back();
    return this->deck.back();
   
}


void Deck::swap(Card *first_position, Card *second_position){
    Card temp = *first_position;
    *first_position = *second_position;
    *second_position = temp;
}

std::string Deck::to_string(){
    std::string str = "";
    std::vector<Card> deck_Copy;
    for(int j = 0; j < MAX; j++){
        deck_Copy.push_back(this->deck[j]);
    }
    for(int i = 0; i < MAX; i++){
        
       str+=deck_Copy.back().toString();
       deck_Copy.pop_back();


    }
    return str;

}