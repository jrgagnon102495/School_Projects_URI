#include <iostream>
#include "player.h"
#include "card.h"

#include <stack>
#include "dealer.h"
#include <sstream>

Player::Player(std::stack<int>chips1, std::stack<int>chips5, std::stack<int>chips10, std::stack<int>chips25, std::stack<int>chips50, std::vector<Card> playHand){
    this->chips1 = chips1;
    this->chips5 = chips5;
    this->chips10 = chips10;
    this->chips25 = chips25;
    this->chips50 = chips50;
    
    
    
    this->card_amount = 2;
    
   for(int i =0; i < playHand.size(); i++){
       
       this->hand.push_back(playHand[i]);
    //   std::cout<<this->hand[i].toString()<<std::endl;
   }
}
Player::Player(){
    
    std:: stack<int> chips1;
     std:: stack<int> chips5;
      std:: stack<int> chips10;
       std:: stack<int> chips25;
        std:: stack<int> chips50;
      //1 stack
     chips1.push(1);
      chips1.push(1);
       chips1.push(1);
        chips1.push(1);
         chips1.push(1);

     //5 stack
     chips5.push(5);
       chips5.push(5);
         chips5.push(5);
             chips5.push(5);

     //10 stack
     chips10.push(10);
     chips10.push(10);
     chips10.push(10);

     //15 stack
     chips25.push(25);
     chips25.push(25);


     //25
     chips50.push(50);
this->chips1 = chips1;
    this->chips5 = chips5;
    this->chips10 = chips10;
    this->chips25 = chips25;
    this->chips50 = chips50;
    
    
}
void Player::hitRight(Card card){
     splitR.push_back(card);
       this->card_amount++;
}


void Player::hitLeft(Card card){
     splitL.push_back(card);
       this->card_amount++;
}
int Player::doubleLeft(Card card, int chip_amount){
    splitL.push_back(card);
    if(chip_amount == 1){
        if(chips1.empty()){
            return bet_amount;
        }
        
        chips1.pop();
        bet_amount++;
        return bet_amount;
    }
    else if(chip_amount == 5){
        if(chips5.empty()){
            return bet_amount;
        }
        chips5.pop();
        bet_amount+=5;
        return bet_amount;
    }
    else if(chip_amount == 10){
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
    else if(chip_amount == 25){
        if(chips25.empty()){
            return bet_amount;
        }
        chips25.pop();
        bet_amount+=25;
        return bet_amount;
    }
    else if(chip_amount == 50){
        if(chips50.empty()){
            return bet_amount;
        }
        chips50.pop();
        bet_amount+=50;
        return bet_amount;
    }
    else{
        chip_amount = 10;
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
}
int Player::doubleRight(Card card, int chip_amount){
    splitR.push_back(card);
    
    if(chip_amount == 1){
        if(chips1.empty()){
            return bet_amount;
        }
        
        chips1.pop();
        bet_amount++;
        return bet_amount;
    }
    else if(chip_amount == 5){
        if(chips5.empty()){
            return bet_amount;
        }
        chips5.pop();
        bet_amount+=5;
        return bet_amount;
    }
    else if(chip_amount == 10){
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
    else if(chip_amount == 25){
        if(chips25.empty()){
            return bet_amount;
        }
        chips25.pop();
        bet_amount+=25;
        return bet_amount;
    }
    else if(chip_amount == 50){
        if(chips50.empty()){
            return bet_amount;
        }
        chips50.pop();
        bet_amount+=50;
        return bet_amount;
    }
    else{
        chip_amount = 10;
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
}
void Player::split(std::vector<Card> hand){
   this->splitL.push_back(this->hand.front());
   
   
   this->splitR.push_back(this->hand.back());
   
}
std::vector<Card> Player::splitLeft(){
    
    return this->splitL;
}
std::vector<Card> Player::splitRight(){
   
    return this->splitR;
}
std::vector<Card> Player::getCards(){
 return this->hand;
}

std::stack<int> Player::getChips1(){
    return chips1;
}
std::stack<int> Player::getChips5(){
    return chips5;
}
std::stack<int> Player::getChips10(){
    return chips10;
}
std::stack<int> Player::getChips25(){
    return chips25;
}
std::stack<int> Player::getChips50(){
    return chips50;
}
int Player::betAmount(int chip_amount){
    if(chip_amount == 1){
        if(chips1.empty()){
            return bet_amount;
        }
        chips1.pop();
        bet_amount++;
        return bet_amount;
    }
    else if(chip_amount == 5){
        if(chips5.empty()){
            return bet_amount;
        }
        chips5.pop();
        bet_amount+=5;
         return bet_amount;
    }
    else if(chip_amount == 10){
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
         return bet_amount;
    }
    else if(chip_amount == 25){
        if(chips25.empty()){
            return bet_amount;
        }
        chips25.pop();
        bet_amount+=25;
         return bet_amount;
    }
    else if(chip_amount == 50){
        if(chips50.empty()){
            return bet_amount;
        }
        chips50.pop();
        bet_amount+=50;
         return bet_amount;
    }
    else{
        chip_amount = 10;
        if(chips10.empty()){
            return bet_amount;
        }
        
            chips10.pop();
            bet_amount+=10;
            return bet_amount;
        
        
    }
    if(chips1.empty() &&  chips5.empty() && chips10.empty() && chips25.empty() && chips50.empty()){
        bet_amount = -1;
            
        
    }
    return chip_amount;
}
void Player::hitCard(Card card){
       hand.push_back(card);
       this->card_amount++;
}
int Player::doubleDown(Card card, int chip_amount){
    hand.push_back(card);
    if(chip_amount == 1){
        if(chips1.empty()){
            return bet_amount;
        }
        
        chips1.pop();
        bet_amount++;
        return bet_amount;
    }
    else if(chip_amount == 5){
        if(chips5.empty()){
            return bet_amount;
        }
        chips5.pop();
        bet_amount+=5;
        return bet_amount;
    }
    else if(chip_amount == 10){
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
    else if(chip_amount == 25){
        if(chips25.empty()){
            return bet_amount;
        }
        chips25.pop();
        bet_amount+=25;
        return bet_amount;
    }
    else if(chip_amount == 50){
        if(chips50.empty()){
            return bet_amount;
        }
        chips50.pop();
        bet_amount+=50;
        return bet_amount;
    }
    else{
        chip_amount = 10;
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
        return bet_amount;
    }
}
int Player::getBetAmount(){
    return this->bet_amount;
}

int Player::insuranceBet(int chip_amount){
   if(chip_amount == 1){
        if(chips1.empty()){
            return bet_amount;
        }
        chips1.pop();
        bet_amount++;
        return bet_amount;
    }
    else if(chip_amount == 5){
        if(chips5.empty()){
            return bet_amount;
        }
        chips5.pop();
        bet_amount+=5;
         return bet_amount;
    }
    else if(chip_amount == 10){
        if(chips10.empty()){
            return bet_amount;
        }
        chips10.pop();
        bet_amount+=10;
         return bet_amount;
    }
    else if(chip_amount == 25){
        if(chips25.empty()){
            return bet_amount;
        }
        chips25.pop();
        bet_amount+=25;
         return bet_amount;
    }
    else if(chip_amount == 50){
        if(chips50.empty()){
            return bet_amount;
        }
        chips50.pop();
        bet_amount+=50;
         return bet_amount;
    }
    else{
        chip_amount = 10;
        if(chips10.empty()){
            return bet_amount;
        }
        
            chips10.pop();
            bet_amount+=10;
            return bet_amount;
        
        
    }
    if(chips1.empty() &&  chips5.empty() && chips10.empty() && chips25.empty() && chips50.empty()){
        bet_amount = -1;
            
        
    }
    return chip_amount; 
}
bool Player::isSplit(){
    if(splitcheck){
        return true;
    }
    return false;
}

std::vector<Card> Player::dealCards(std::vector<Card> copyDeck){
 
    if(copyDeck.empty()){
        return copyDeck;
    }
    
     for(int i =0; i < 2 ; i++){
       
       this->hand.push_back(copyDeck.back());
       this->card_amount++;
       copyDeck.pop_back();
    //   std::cout<<this->hand[i].toString()<<std::endl;
   }
   
   return copyDeck;
}

void Player::giveBack(){
    this->hand.clear();
}
int  Player::getCardAmount(){
   return this->card_amount;
}
std::vector<Card> Player::changeAceVal(std::vector<Card> hand){
    char choice;
    for(int i = 0; i < this->card_amount; i++){
        if(this->hand[i].getFace() == 'A'){
        std::cout<<"Change Ace Value(Y or N ?): "<<std::endl;
        std::cin>>choice;
        if(choice == 'Y' || choice == 'y')
            this->hand[i].setValue(1);
            return this->hand;
        }
        
    
    }
    
    return this->hand;
}

std::string Player::to_string(){
    std::string str = "";
    str+="Cards: ";
    // std::cout<<this->card_amount<<std::endl;
     std::vector<Card>copyHand;
    // for(int j = 0; j < this->card_amount; j++){
    //     copyHand.push_back(this->hand[j]);
    //     // std::cout<<this->hand[j].toString()<<std::endl;
        
    // }
     std::stringstream ss;
    // std::cout<<this->card_amount<<std::endl;
     str+="\n";
    for(int i = this->hand.size()-1; i>=0;  i-- ){
      
      
     
        str+=this->hand[i].toString();
    
        str+=" ";
    
        
    }
    str+="\n";
    str+="Chips: \n";
    
    for (std::stack<int> displayChips1 = chips1; !displayChips1.empty(); displayChips1.pop()){
        
        str+=" [";
        std::stringstream ss1;
        ss1 << displayChips1.top();
        
        str+=ss1.str();
        str+="] ";
    }
        str+="\n";
        
    for (std::stack<int> displayChips5 = chips5; !displayChips5.empty(); displayChips5.pop()){
        str+=" [";
        std::stringstream ss5;
        ss5 << displayChips5.top();
        str += ss5.str();
        str+="] ";
    }
        str+="\n";
    for (std::stack<int> displayChips10 = chips10; !displayChips10.empty(); displayChips10.pop()){
        str+=" [";
        std::stringstream ss10;
        ss10 << displayChips10.top();
        str+=ss10.str();
        str+="] ";
    }
    str+="\n";
    for (std::stack<int> displayChips25 = chips25; !displayChips25.empty(); displayChips25.pop()){
        str+=" [";
        std::stringstream ss25;
        ss25 << displayChips25.top();
        str+=ss25.str();
        str+="] ";
    }
    str+="\n";
    for (std::stack<int> displayChips50 = chips50; !displayChips50.empty(); displayChips50.pop()){
        str+=" [";
        std::stringstream ss50;
        ss50 << displayChips50.top();
        str+=ss50.str();
        str+="] ";
    }
    str+="\n";
    //  for (std::stack<int> displayChips1 = chips1; !displayChips1.empty(); displayChips1.pop()){
        
    //     str+=" [";
    //     std::stringstream ss1;
    //     ss1 << displayChips1.top();
        
    //     str+=ss1.str();
    //     str+="] ";
    // }
    //     str="\n";
    
    return str;

}
std::string Player:: to_stringSplit(){
    
    std::string str = "";
    str+="Cards: ";
    // std::cout<<this->card_amount<<std::endl;
     std::vector<Card>copyHand;
    // for(int j = 0; j < this->card_amount; j++){
    //     copyHand.push_back(this->hand[j]);
    //     // std::cout<<this->hand[j].toString()<<std::endl;
        
    // }
     std::stringstream ss;
    // std::cout<<this->card_amount<<std::endl;
     str+="\n";
    for(int i = this->splitR.size()-1; i>=0;  i-- ){
      
      
     
        str+=this->splitR[i].toString();
    
        str+=" ";
    
        
    }
    str+="\n";
     for(int i = this->splitL.size()-1; i>=0;  i-- ){
      
      
     
        str+=this->splitL[i].toString();
    
        str+=" ";
    
        
    }
    str+="Chips: \n";
    
    for (std::stack<int> displayChips1 = chips1; !displayChips1.empty(); displayChips1.pop()){
        
        str+=" [";
        std::stringstream ss1;
        ss1 << displayChips1.top();
        
        str+=ss1.str();
        str+="] ";
    }
        str+="\n";
        
    for (std::stack<int> displayChips5 = chips5; !displayChips5.empty(); displayChips5.pop()){
        str+=" [";
        std::stringstream ss5;
        ss5 << displayChips5.top();
        str += ss5.str();
        str+="] ";
    }
        str+="\n";
    for (std::stack<int> displayChips10 = chips10; !displayChips10.empty(); displayChips10.pop()){
        str+=" [";
        std::stringstream ss10;
        ss10 << displayChips10.top();
        str+=ss10.str();
        str+="] ";
    }
    str+="\n";
    for (std::stack<int> displayChips25 = chips25; !displayChips25.empty(); displayChips25.pop()){
        str+=" [";
        std::stringstream ss25;
        ss25 << displayChips25.top();
        str+=ss25.str();
        str+="] ";
    }
    str+="\n";
    for (std::stack<int> displayChips50 = chips50; !displayChips50.empty(); displayChips50.pop()){
        str+=" [";
        std::stringstream ss50;
        ss50 << displayChips50.top();
        str+=ss50.str();
        str+="] ";
    }
    str+="\n";
    //  for (std::stack<int> displayChips1 = chips1; !displayChips1.empty(); displayChips1.pop()){
        
    //     str+=" [";
    //     std::stringstream ss1;
    //     ss1 << displayChips1.top();
        
    //     str+=ss1.str();
    //     str+="] ";
    // }
    //     str="\n";
    
    return str;
 
}