#ifndef TABLE_H
#define TABLE_H

#include <queue>
#include "player.h"
#include "dealer.h"
#include <vector>
#define MAX_PLAYERS 4
class Table{
    private:
    std::queue<Player> players;
    Player *spaces[MAX_PLAYERS];
    int maxPlayers;
    Dealer dealer;
    int numberOfPlayers;
    public:
    Table(Dealer dealer, std::queue<Player>players, int maxPlayers, Player *spaces[]);
    void space(std::vector<Card> remDeck);
    Player* getSpace1();
    Player* getSpace2();
    Player* getSpace3();
    Player* getSpace4();
    int getNumberOfPlayers();
    std::string to_stringBG();
    
    std::string to_stringAG();
    std::string to_stringAGSplit();
};

#endif